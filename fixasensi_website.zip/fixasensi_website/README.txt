FIXASENSI WEBSITE — QUICK START

1. Open index.html in a browser to preview the site.
2. Replace https://instagram.com/ in index.html with your real Instagram profile URL.
3. Edit the sample sensitivity numbers and descriptions so they match your own tested presets.
4. Replace the premium pack placeholder prices/details and connect a secure payment + delivery provider before taking orders.
5. Publish for free using GitHub Pages:
   - Create/sign in to a GitHub account.
   - Create a public repository named fixasensi.
   - Upload index.html to the repository root.
   - Open Settings > Pages, choose Deploy from a branch, select main / root, and Save.
   - GitHub will provide your public website address after deployment.

This is a static front-end website. It does not include a payment backend, user accounts, analytics, or automatic file delivery.
The sensitivity values are example starter values, not guaranteed or officially tested settings.
